import tkinter as tk
import random
import winsound
import pygame

pygame.mixer.init()

sc = tk.Tk()
sc.title("ביפ ביפ תוכנת תינוקות")
sc.geometry("400x400")
sc.configure(bg="light blue")
sc.attributes('-fullscreen', True)  # הגדרת החלון כמסך מלא

txt = "תוכנת תינוקות"
input_label = tk.Label(sc, text=txt, font=("Levenim MT", 23, "bold"), fg="green", bg="light blue")
input_label.pack(pady=10)

txt3 = "נא הקלד את הסיסמה הנכונה בשביל לסגור את החלון"
input_label = tk.Label(sc, text=txt3, font=("Arial", 23), fg="green", bg="light blue")
input_label.pack(pady=15)

entry = tk.Entry(sc, font=("Arial", 23))
entry.pack(pady=15)

def close():
    ge = entry.get()
    if ge == "052":
        sc.destroy()  # סגירת החלון אם הסיסמה נכונה
    else:
        txt5 = "הסיסמה שגויה"
        input_label = tk.Label(sc, text=txt5, font=("Arial", 25), fg="red", bg="light blue")
        input_label.pack(pady=15)

button1 = tk.Button(sc, text="סגור את החלון אם הסיסמה נכונה", command=close, font=("Arial", 16), bg=None, fg="blue", width=30, height=2)
button1.pack(pady=15)

def disable_keys(event):
    return "break"  # מונע את הפעולה של המקשים

sc.bind("<Tab>", disable_keys)  # מניעת שימוש במקש Tab
sc.bind("<Alt_L>", disable_keys)  # מניעת שימוש במקש Alt שמאלי
sc.bind("<Alt_R>", disable_keys)  # מניעת שימוש במקש Alt ימני
sc.bind("<Alt-F4>", disable_keys)  # מניעת שימוש במקש Alt + F4


sc.grab_set()  # מונע מעבר לחלונות אחרים

sc.wm_attributes("-topmost", True)  # שומר על החלון מעל כל החלונות האחרים
sc.wm_attributes("-fullscreen", True)  # הגדרת החלון כמסך מלא

def disable_alt_tab(event):
    if event.state == 4 and event.keysym == 'Tab':  # מצב Alt ולחיצה על Tab
        return "break"  # מונע את הפעולה של Alt + Tab

sc.bind("<KeyPress>", disable_alt_tab)    # מניעת שימוש בשילוב Alt + Tab

def animate_space(event):
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    sc.configure(bg=f'#{r:02x}{g:02x}{b:02x}')  # שינוי צבע הרקע

sc.bind("<Key>", animate_space)  # קישור כל המקשים לפונקציה

def play_cat_sound(event):
    try:
        pygame.mixer.music.load('catsound.wav')
        pygame.mixer.music.play()
    except Exception as e:
        print(f"שגיאה בהשמעת צליל חתול: {e}")

def play_dog_sound(event):
    try:
        pygame.mixer.music.load('dogsound.wav')
        pygame.mixer.music.play()
    except Exception as e:
        print(f"שגיאה בהשמעת צליל כלב: {e}")

dog_img = tk.PhotoImage(file="dog (1).gif")
cat_img = tk.PhotoImage(file="cat (1).gif")
dog_label = tk.Label(sc, image=dog_img, bg="light blue")
dog_label.place(x=400, y=350)
cat_label = tk.Label(sc, image=cat_img, bg="light blue")
cat_label.place(x=800, y=350)
dog_label.bind("<Button-1>", play_dog_sound)
cat_label.bind("<Button-1>", play_cat_sound)

sc.mainloop()